
<img width="512" height="512" alt="generated_image_20251129224205" src="https://github.com/user-attachments/assets/54661238-b11e-40be-ab12-4a49f6a036dd" />


## 插件下载

[https://github.com/LiuYangArt/PSBananaUXP/tree/main/Plugin](https://github.com/LiuYangArt/PSBananaUXP/tree/main/Plugin)

## 插件安装

### 手动安装
- 解压放到 C:\Program Files\Adobe\Adobe Photoshop 202x\Plug-ins\
<img width="1051" height="240" alt="image" src="https://github.com/user-attachments/assets/c8353ef4-0ff2-4db6-a699-c48efd0765c4" />
- plugins>PSBanana
<img width="1072" height="396" alt="image" src="https://github.com/user-attachments/assets/451513f8-da4b-4b26-9232-36701bbdb479" />

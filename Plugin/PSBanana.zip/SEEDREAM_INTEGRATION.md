# Seedream API 集成说明

## 概述

PSBananaUXP 插件已支持 Seedream 4.5 API (豆包 AI 生图)。

## API 信息

- **Provider 名称**: Seedream 4.5
- **API Endpoint**: `https://ark.cn-beijing.volces.com/api/v3/images/generations`
- **默认模型**: `doubao-seedream-4-5-251128`
- **认证方式**: Bearer Token (API Key)

## 配置方法

### 获取 API Key

1. 访问 [火山方舟控制台](https://console.volcengine.com/ark)
2. 进入「API 管理」页面
3. 创建或获取 API Key
4. **重要**: Seedream API 使用的是火山方舟的 API Key，格式通常为：
   - 长格式：如 `27a408f9-d98a-44bb-ac12-c74b1d66b889`
   - 或者是以 `ak-` 开头的格式

### 在插件中配置

1. 在 Settings 标签页选择或添加 "Seedream 4.5" provider
2. 填写以下信息:
   - **API Key**: 你的火山方舟 API Key (从控制台获取)
   - **Base URL**: `https://ark.cn-beijing.volces.com/api/v3/images/generations`
   - **Model ID**: `doubao-seedream-4-5-251128` (或其他 Seedream 模型)
3. 点击「Test Connection」测试连接（会提示无法自动测试，这是正常的）
4. 点击「Save」保存配置

## 功能特性

### 支持的功能

✅ **文生图 (Text to Image)**
- 根据文本描述生成图片
- 自动在 prompt 中添加宽高比描述

✅ **图生图 (Image Edit)**
- 支持单图输入 (使用 base64 格式)
- 支持多图模式 (优先使用 source 图片)

✅ **分辨率设置**
- **Seedream 4.5**: 仅支持 2K, 4K (不支持 1K)
- **Seedream 4.0**: 支持 1K, 2K, 4K
- **Seedream 3.0**: 支持 1K, 2K
- 默认使用 2K
- **注意**: 如果选择 1K 但使用 4.5 模型，会自动转换为 2K

✅ **宽高比支持**
- 自动在 prompt 中添加自然语言宽高比描述
- 支持: 1:1, 4:3, 3:4, 16:9, 9:16, 21:9, 3:2, 2:3

### 不支持的功能

❌ **Search Web**: Seedream API 不支持网络搜索工具
❌ **多图融合**: Seedream 仅支持单张图片输入 (多图模式会只使用第一张)

## 请求格式

### 文生图示例

```json
{
  "model": "doubao-seedream-4-5-251128",
  "prompt": "充满活力的特写编辑肖像，模特眼神犀利. Aspect ratio 16:9, wide landscape format",
  "size": "2K",
  "watermark": false
}
```

### 图生图示例

```json
{
  "model": "doubao-seedream-4-5-251128",
  "prompt": "保持模特姿势和液态服装的流动形状不变. Aspect ratio 1:1, square format",
  "image": "data:image/png;base64,iVBORw0KG...",
  "size": "2K",
  "watermark": false
}
```

## 响应格式

```json
{
  "model": "doubao-seedream-4-5-251128",
  "created": 1757323224,
  "data": [
    {
      "url": "https://...",
      "size": "1760x2368"
    }
  ],
  "usage": {
    "generated_images": 1,
    "output_tokens": 16280,
    "total_tokens": 16280
  }
}
```

## 实现细节

### Provider 检测

通过以下方式识别 Seedream provider:
- Provider 名称包含 "seedream"
- Base URL 包含 "ark.cn-beijing.volces.com"

### 宽高比处理

与 GPTGod 类似，Seedream 需要在 prompt 中描述宽高比:

```javascript
// 示例
"16:9" -> "Aspect ratio 16:9, wide landscape format"
"9:16" -> "Aspect ratio 9:16, tall portrait format"
```

### 图片输入

- 使用 base64 格式: `data:image/png;base64,...`
- 单图模式: 使用 `image` 字段
- 多图模式: 只发送第一张图片 (优先 sourceImage)

### 响应处理

- 从 `data[0].url` 提取图片 URL
- 下载图片到本地临时文件
- 返回 UXP File 对象

## 注意事项

1. **连接测试**: Seedream API 不提供 `/models` 端点，无法自动测试连接，请通过实际生图验证
2. **水印**: 默认设置为 `watermark: false` (不添加水印)
3. **图片格式**: 返回的图片为 JPEG 格式
4. **多图限制**: 虽然插件支持多图模式，但 Seedream API 只接受单张图片输入

### 常见错误

#### 400 InvalidParameter - Size Not Supported

```
The parameter `size` specified in the request is not valid: 
the specified size is not supported for model doubao-seedream-4-5
```

**原因**:
- Seedream 4.5 模型不支持 `1K` 分辨率
- 只支持 `2K` 和 `4K`

**解决方法**:
1. 在插件中选择 `2K` 或 `4K` 分辨率（不要选 `1K`）
2. 代码已自动处理：选择 `1K` 时会自动转换为 `2K`
3. 或者使用 Seedream 4.0 模型（支持 1K）

#### 401 AuthenticationError

```
The API key format is incorrect
```

**原因**:
- API Key 填写错误或无效
- 使用了错误的 Provider (不是 Seedream 4.5)
- Base URL 不正确

**解决方法**:
1. 检查 API Key 是否从火山方舟控制台正确获取
2. 确认选择的 Provider 是 "Seedream 4.5"
3. 确认 Base URL 为: `https://ark.cn-beijing.volces.com/api/v3/images/generations`
4. 尝试重新生成 API Key
5. 检查 API Key 是否有图像生成权限

#### 其他常见问题

- **模型不存在**: 检查 Model ID 是否正确
- **超出配额**: 检查账户余额和请求限制
- **图片格式错误**: 确保输入图片符合 Seedream 要求

## 常见模型 ID

- `doubao-seedream-4-5-251128` - Seedream 4.5 (最新)
- `doubao-seedream-4.0` - Seedream 4.0
- `doubao-seedream-3.0-t2i` - Seedream 3.0 文生图
- `doubao-seededit-3.0-i2i` - Seedream 3.0 图生图

## 参考文档

- [Seedream 4.5 API 文档](https://www.volcengine.com/docs/82379/1367501)
- [豆包 AI 生图 API](https://ark.cn-beijing.volces.com/)
